# -*- coding: utf-8 -*-
"""
Created on Wed Mar  3 11:55:23 2021

@author: smattoo5
"""
import pandas as pd
import numpy as np
from collections import defaultdict
from word2number import w2n
import re
import requests
import json
import math

#import statistics
# import spacy
# import en_core_web_sm
# nlp = en_core_web_sm.load()

from nltk.tokenize import word_tokenize 
import time
from requests.auth import HTTPBasicAuth

from concurrent.futures import ThreadPoolExecutor
import threading
import ast # convert dictionary string to dictionary

import concepts_keywords as nounphrase
#import PoolPartyExtraction as pp # Not Needed
#import medianParser as par 

import config as config
musthaveskill = config.musthaveskill
unwantedPhrase = config.unwantedKeyword
unwantedBigram = config.unwantedBigram
staging = config.staging_environment

if staging:
    url = config.stagingurl
    username = config.staging_username
    password = config.staging_password
    annot = '/aes/dev/ml'
else:
    url = config.produrl
    username = config.prod_username
    password = config.prod_password
    annot = '/aes/ml'
    
    
    
def readText(text):
    # Parse the input
    result = text.split("\n")
    sentences = [each for each in result if len(each)>1]
    return sentences
   
def labelskill_new(sentences, musthaveskill):
    """
    Parameters
    ----------
    Dated: 7th April 2021
    ## As per new change the input can be a paragraph
    We will only extract Primary and secondary sentences
    
    #### Old Details ###
    sentences : input sentence from JD 
    musthaveskill : list of tokens which can identify the Primary Skill
    -------
    RETURNS
    skilldict : dictionary where each sentence of JD is marked with the skill, either primary or secondary 
    PS, SS : Subset of JD which has only Primary skill body & Secondary skill body (This will be used by PP Later)
    PS_Sentences, SS_Sentences : Dictionary with Key as description and value as Experience in Years
    max(minumum_experience) : maximum number of Experience from JD
   """
   ## Variable declartion
    
    skilldict = dict()
    PS_Sentences, SS_Sentences = [], []
    
    for sentence in sentences:
        tokens = [each.lower().strip() for each in sentence.split(" ")]
        
        if (any(each in tokens for each in musthaveskill)):
            skilldict.update({sentence:'PS'})
            PS_Sentences.append(sentence)
        else:
            skilldict.update({sentence:'SS'})
            SS_Sentences.append(sentence)
       
        
    ## Creating the Primary and Secondary body to extract the skills from Pool party  
    # Primary Skill
    PS = " ".join(PS_Sentences)
    PS = re.sub('[^a-zA-Z0-9]+', ' ', PS)
    # Secondary Skill
    SS = " ".join(SS_Sentences)
    SS = re.sub('[^a-zA-Z0-9]+', ' ', SS)
    return skilldict, PS, SS

""" Clean JD Parser """    
def cleanUnigrams(phrases):
    
    for each in phrases[:]:
        
        # Clean Unigrams
        for token in word_tokenize(each):
            
            token = token.lower()
            # If any token has only Single Character -- IGNORE
            if len(token) == 1:
                phrases.remove(each)
                break
            # If any token is from unwanted Phrase -- IGNORE
            if token in unwantedPhrase:
                
                phrases.remove(each)
                
                break
          
    return phrases


"""Find phrases from JD and remove unwanted phrases"""
def findphrases(sentences, prime_skill, sec_skill):
    
    phrases, skill_token = [], []
    jd_phrases = {}
    for sentence in sentences:
        #phrases = nounphrase.Main(sentence)
        for phrase in nounphrase.Main(sentence):
            # Augument the text to be in lower and stip form
            
            token = phrase.lower().strip()
            
            
            
            if len(token)>1:
                if token not in unwantedBigram:
                    phrases.append(phrase)
                    
    phrases = [each for each in phrases if len(word_tokenize(each)) > 1]
    phrases = list(set([each for each in phrases for token in word_tokenize(each) if token[0].isupper()]))
    
    phrases = cleanUnigrams(phrases)
    jd_phrases = {each:[e.lower() for e in  word_tokenize(each)]for each in phrases }
    
    # Get Primary Skill and Secondary Skill Token
    skill_token = [ e for each in prime_skill  for e in word_tokenize(each)] + [ e for each in sec_skill  for e in word_tokenize(each)]
    skill_token = [each.lower() for each in skill_token]
    
    # Remove the JD Phrase if it has any match for the Primary or Secondary Skill
    phrases = [key for key,value in jd_phrases.items() if not(set(value) & set(skill_token))]
    
    # Remove Years
    removeTime = 'yrs|yr|years|year|mnts|mnt|months|month'
    for e in phrases:
        if (len(re.findall(removeTime, e, flags=re.IGNORECASE))>0):
            phrases.remove(e)
    return phrases


""" Find the skills using PoolParty """
def Skill_industry(text):
    """url is imported from config file"""
    searchurl = url+text
    response=requests.get(searchurl,auth=HTTPBasicAuth(username, password)).json()
    if len(response) > 0:
        
        Res = response['concepts']
        skill, industry  = [], []
           
        for each in Res:
            if each['conceptSchemes'][0]['title'] == 'Skills':
                skill.append(each['prefLabels']['en'])
            if each['conceptSchemes'][0]['title'] == 'Industry':
                industry.append(each['prefLabels']['en'])
        
                
        skill  = list(set(skill))  # Remove the duplicate
        industry = list(set(industry)) # Remove the duplicate
    
    else:
        skill, industry  = [], []
    return skill, industry



""" Implement threading to fetch skills for primary and secondary description"""
# Updated 15Jan2021
# Added prim_industry, second_industry
def skill_threading(primarybody, secondarybody):
    primarypoolpartyskill, secondarypoolpartyskill, prim_industry = [], [], []
    #starttime = time.time()
    with ThreadPoolExecutor(max_workers=5) as executor:
        if len(primarybody) > 0:
            psk = executor.submit(Skill_industry, (primarybody))
            primarypoolpartyskill = psk.result()[0]
            prim_industry = psk.result()[1]
        else:
            primarypoolpartyskill, prim_industry = [], []
        if len(secondarybody) > 0:
            ssk = executor.submit(Skill_industry, (secondarybody))
            secondarypoolpartyskill = ssk.result()[0]
            second_industry = ssk.result()[1]
        else:
            secondarypoolpartyskill, second_industry = [], []
    
    
    #primarypoolpartyskill = ast.literal_eval(psk.result())
    #secondarypoolpartyskill = ast.literal_eval(ssk.result())
    #endtime = time.time() -starttime
    primarypoolpartyskill = list(set(primarypoolpartyskill))
    secondarypoolpartyskill = list(set(secondarypoolpartyskill))
    industry = list(set(prim_industry+second_industry))

    return primarypoolpartyskill, secondarypoolpartyskill, industry

""" find all possible email address from the body"""
def findEmail(sentences):
    email = [re.findall('\S+@\S+', _) for _ in sentences]
    email = [e1 for e in email if len(e) >0 for e1 in e]
    return email

""" Conver the decimal into integer """
def decimalAugumentation(text):
    #text = text.replace('-', 'to')
    # Check for .
    for e in re.findall('\d+\.+\d', text):
        text = text.replace(e, e.split(".")[0])
    # Check for +
    for e in re.findall('[0-9][+]', text):
        text = text.replace(e, e.split("+")[0])
    return text

""" Convert Range into single digit number"""
def rangeConversion(list_, text):
    
    for each in list_:
        text = text.replace(each, str(int(np.median([int(float(e2)) for e2 in re.split("[-|'to']",each) if e2 != ""])))+" ")
        
        #list_of_val = [int(float(e2)) for e2 in each.split("-")]
        #value = np.median([int(float(e2)) for e2 in each.split("-")])
        #text = text.replace(each, str(int(np.median([int(float(e2)) for e2 in each.split("-")])))+" ")
    return text

""" Find the median Experience from the body"""
# Added on 07-04-2021
# To handle the paragraph based body
def findExperience(text):
    # Check if exp is mentioned in a Range
    # Extract the range    
    monthrange = re.findall(r"(\(*\d.[-|'to' \d.()]*\d.)\s*(?=[months|m])", text)
    yearrange = re.findall(r"(\(*\d.[-|'to' \d.()]*\d.)\s*(?=[years|y])", text)
    
    # Convert the range into single value
    text = rangeConversion(monthrange, text)
    text = rangeConversion(yearrange, text)
    
    # Find all the experience in years
    year=re.findall("(\d+\.*\d*)\s*(?=[year|y])",text)
    
    # Find all the experience in months
    month = re.findall("(\d+)\s*(?=[month|m])",text)
    
    # Convert months into year
    month = [math.ceil(int(float(e))/12) for e in month]
    
    # Convert String value into int
    year = [int(float(each)) for each in year]
    total = month+year
    # Find Median of combined Month and Year
    # Return -1 if body has no experience mentioned
    if len(total) > 0:
        exp = int(np.median(month+year))
    else:
        exp = -1
          
    return exp

""" Convert Words into Number """
def word_to_num(text):
    for each in text.split(" "):
        try:
            digit = w2n.word_to_num(each)
            text = text.replace(str(each), str(digit))
        
        except Exception as e:
            digit = ""
    return text
           
def jdParse(text):
    """
    

    Parameters
    ----------
    text : String
        DESCRIPTION : read the Json as input body

    Returns
    -------
    Display : Dictionary
        DESCRIPTION : Display the output

    """
    Display = {}
    
    text = decimalAugumentation(text)
    text = word_to_num(text)
    medianExp = findExperience(text)
    sentences = readText(text)
    filterSentences = [re.sub('[^a-zA-Z0-9]+', ' ', _) for _ in sentences]
    email = findEmail(sentences) # Find Email
    
    #skillset , primarybody, secondarybody, prime_sent, sec_sent, minumum_experience = labelskill(sentences, musthaveskill)
    skillset , primarybody, secondarybody  = labelskill_new(sentences, musthaveskill)
    #medianExp = medianExperience(minumum_experience)
    
    primary_skills, secondary_skills, industry = skill_threading(primarybody, secondarybody)
    
    #Remove Duplicate
    primary_skills = list(set(primary_skills))
    secondary_skills = list(set(secondary_skills))
    
    #Remove Duplicates in Secondary Skills
    secondary_skills = list(set(secondary_skills).difference(set(primary_skills)))
    
    try:
        jd_phrases = findphrases(filterSentences, primary_skills, secondary_skills)
    except Exception as e:
        jd_phrases = []
    
    Display.update({"minExperience": medianExp,
               "primarySkills" : primary_skills,
               "secondarySkills": secondary_skills,
               "jdPhrases": jd_phrases,
               "industry":industry,
               "role": " ",
               "certifications":" ",
               "email": email,
               "freeText": filterSentences})
    
    return Display



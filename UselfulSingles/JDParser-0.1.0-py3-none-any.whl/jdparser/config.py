# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 15:53:10 2020

@author: smattoo5
"""

#staging = "https://staging-vocabulary.dxc.com/extractor/api/extract?language=en&projectId="

staging_environment = True

dev = {'url' :'https://staging-vocabulary.dxc.com/extractor/api/extract?language=',
       'projectId' : '1E14DEE6-1A7A-0001-18F8-15701CE0B3E0',
       'username': 'API_PP_staging','password': 'f2Nnc68d',
       }

prod = {'url' :'https://vocabulary.dxc.com/extractor/api/extract?language=',
       'projectId' : '1E262283-9BC3-0001-E4DD-CEFF15D51DBA',
       'username' :'API_PP','password' : 'aZ5c29SL',
       }

language='en'
numberOfTerms=0
disambiguate=True
conceptMinimumScore=35.0
conceptSchemeFilters= 'https://vocabulary.dxc.com/DigitalNow/20385,https://vocabulary.dxc.com/DigitalNow/0'


def geturl(envdict):
    return envdict['url']+language+"&projectId="+envdict['projectId']+"&numberOfTerms="+str(numberOfTerms)+"&disambiguate="+str(disambiguate)+"&conceptSchemeFilters="+conceptSchemeFilters+"&text="



#musthaveskill = ['mandatory', 'strong', 'must', 'should', 'solid', 'need', 'needed', 'atleast', 'minimum', 'maximum', 'desirable']
#musthaveskill = ['mandatory', 'strong', 'must', 'should', 'solid', 'need', 'needed', 'atleast', 'minimum', 'maximum', 'fluent', 'experience','proficient', 'hands-on', 'handson', 'active', 'actively','expert','master',]

# Primary Cleaning
musthaveskill = ['mandatory', 'strong', 'must', 'should', 'solid', 'need', 'needed', 
                 'atleast', 'minimum', 'maximum', 'fluent', 'experience',
                 'proficient', 'hands-on', 'handson', 'active', 'actively','expert',
                 'master', 'responsible', 'design','drive', 'manage', 'ability']

# JD Parser Cleaning
unwantedKeyword = ['requests', 'both', 'mandatory', 'strong', 'must', 'should', 'solid', 'need',
                   'needed', 'atleast', 'minimum', 'maximum','desirable','new','existing',
                   'experience','technology','proficient','good','relevant', 'high',
                   'low', 'expertise', 'expertize','hands on','hands-on','mastery',
                   'travel','indepdendently','team','collaborate']

unwantedBigram = ['good knowledge', 'overall experience', 'build products', 'run experiments']

stagingurl = geturl(dev)
staging_username = dev['username']
staging_password = dev['password']

produrl = geturl(prod)
prod_username = prod['username'] 
prod_password = prod['password']


    

# staging = {'url_dev' :"https://staging-vocabulary.dxc.com/extractor/api/extract?language=en&projectId=",
#            'projectId_dev': "1E14DEE6-1A7A-0001-18F8-15701CE0B3E0&text=",
#            'username_dev': 'API_PP_staging','password_dev': 'f2Nnc68d',
           
#            }





# staging_username = 'API_PP_staging'
# staging_password = 'f2Nnc68d'

# staging = 'https://staging-vocabulary.dxc.com/extractor/api/extract?language='
# language='en'
# projectId_dev = '1E14DEE6-1A7A-0001-18F8-15701CE0B3E0'
# numberOfTerms=0
# disambiguate=True
# conceptMinimumScore=35.0
# conceptSchemeFilters_dev = 'https://vocabulary.dxc.com/DigitalNow/20385,https://vocabulary.dxc.com/DigitalNow/0'

# stagingurl = staging+language+"&projectId="+projectId_dev+"&numberOfTerms="+str(numberOfTerms)+"&disambiguate="+str(disambiguate)+"&conceptSchemeFilters="+conceptSchemeFilters_dev+"&text="


#https://vocabulary.dxc.com/DigitalNow/0

# url = "https://staging-vocabulary.dxc.com/extractor/api/extract?language=en&projectId=1E14DEE6-1A7A-0001-18F8-15701CE0B3E0&numberOfTerms=0&disambiguate=true&conceptSchemeFilters=https://vocabulary.dxc.com/DigitalNow/20385&text="

# staging = {'url_dev' :"https://staging-vocabulary.dxc.com/extractor/api/extract?language=en&projectId=",
#            'projectId_dev': "1E14DEE6-1A7A-0001-18F8-15701CE0B3E0&text=",
#            'username_dev': 'API_PP_staging','password_dev': 'f2Nnc68d',
#            'sparql_url_dev': 'https://staging-vocabulary.dxc.com/PoolParty/sparql/DigitalNow',
#            }

# prod ={'url_prod' :"https://vocabulary.dxc.com/extractor/api/extract?language=en&projectId=",
#        'projectId_prod' : "1E262283-9BC3-0001-E4DD-CEFF15D51DBA&text=",
#        'username_prod' :'API_PP','password_prod' : 'aZ5c29SL',
#        'sparql_url_prod' :'https://vocabulary.dxc.com/PoolParty/sparql/DigitalNow'
#        }



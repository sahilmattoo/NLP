# -*- coding: utf-8 -*-
"""
Created on Thu Dec  5 18:11:24 2019

@author: smattoo5
"""

import time
import pandas as pd
import re
import requests
import json
from requests.auth import HTTPBasicAuth

#import config as config


"""
#No need to find Narrower and Broader Concepts
import Poolparty_multiprocess as pmp 
"""

def find_entities(inputtext):
    """
    Find the entities using Pool Party API
    """    
    
    #url = config.stagingurl
    
   
    url = "https://staging-vocabulary.dxc.com/extractor/api/extract?language=en&projectId=1E14DEE6-1A7A-0001-18F8-15701CE0B3E0&text="
    
    searchstring = url+inputtext#+ConceptSchemeFilters
    response=requests.get(searchstring,auth=HTTPBasicAuth('API_PP_staging', 'f2Nnc68d')).json()
    #print(time.time()-start)
    Values = ['true' for k in response.keys() if k in 'concepts']
    DF = pd.DataFrame()
    Dictionary_Entity, concept_Display, knoweldgegraph_disp = {}, {}, {}
    List_conceptschemes, List_uri, List_Labels, List_url_f, n_b_concepts  = [], [], [], [], []
    try:        
        if 'true' in Values:
            concepts_values = response["concepts"]
            #starttime = time.time()
            for each in concepts_values:
                List_Labels.append(each['prefLabels']['en'])
                List_conceptschemes.append([e['title'] for e in each['conceptSchemes']][0])
                List_uri.append(each['uri'])
                List_url_f.append('<'+each['uri']+'>')
                """
                Use uri to extract Broader and Narrower concepts:::
                """
#              
        else:
            pass # There is no concepts
        
        
        DF['CS'] = List_conceptschemes
        DF['uri'] = List_uri
        DF['Labels'] = List_Labels
        for i in DF['CS'].unique():
            Dictionary_Entity[i] = [DF['Labels'][j] for j in DF[DF['CS']==i].index]
            knoweldgegraph_disp[i] = [DF['uri'][j] for j in DF[DF['CS']==i].index]
           
    except Exception as e:
        print("Failed to access pool Party")
    
    return Dictionary_Entity, concept_Display, DF, knoweldgegraph_disp
